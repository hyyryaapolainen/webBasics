if (document.readyState !== "loading") {
    console.log("Document is ready!");
    initializeCode();
  } else {
    document.addEventListener("DOMContentLoaded", function () {
      console.log("Document is ready after waiting!");
      initializeCode();
    });
  }
  function initializeCode() {
    var myButton = document.getElementById("my-button");
    var addData = document.getElementById("add-data");
  
    myButton.addEventListener("click", function () {
      document.getElementById("my-title").innerHTML = "My notebook";
      console.log("hello world");
    });
    addData.addEventListener("click", function () {
      var li = document.createElement("li");
      li.innerHTML = document.getElementById("text-area").value;
      document.getElementById("data-list").appendChild(li);
    });
  }