import "./styles.css";

const queryURL = "https://api.tvmaze.com/search/shows?q=";

function setUpDocument() {
  var submitData = document.getElementById("submit-data");
  var queryForm = document.getElementById("query-form");
  var textInput = document.getElementById("input-show");

  queryForm.onsubmit = function () {
    return false;
  };

  submitData.addEventListener("click", async function (event) {
    const showQuery = await fetch(queryURL + textInput.value);
    const showData = await showQuery.json();
    console.log(showData);
    showData.forEach((entry) => {
      let main = document.createElement("div");
      main.className = "show-data";
      let img = document.createElement("img");
      img.src = entry.show.image != null ? entry.show.image.medium : "";
      let info = document.createElement("div");
      let title = document.createElement("h1");
      title.innerText = entry.show.name;
      info.className = "show-info";
      info.appendChild(title);
      main.appendChild(img);
      main.appendChild(info);
      info.insertAdjacentHTML('beforeend', entry.show.summary);
      document.body.appendChild(main);
    });
  });
}
if (document.readyState !== "loading") {
  console.log("Document is ready!");
  setUpDocument();
} else {
  document.addEventListener("DOMContentLoaded", function () {
    console.log("Document is ready after waiting!");
    setUpDocument();
  });
}
