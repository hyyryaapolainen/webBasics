if (document.readyState !== "loading") {
    console.log("Document is ready!");
    initializeCode();
  } else {
    document.addEventListener("DOMContentLoaded", function () {
      console.log("Document is ready after waiting!");
      initializeCode();
    });
  }
  function initializeCode() {
    const table = document.getElementById("data-table");
  
    const submitForm = document.getElementById("submit-data");
    const user = document.getElementById("input-username");
    const email = document.getElementById("input-email");
    const address = document.getElementById("input-address");
    const admin = document.getElementById("input-admin");
    const userimage = document.getElementById("input-image");
  
    const emptyTable = document.getElementById("empty-table");
  
    submitForm.addEventListener("click", function (e) {
      let tableInfo = [
        user.value,
        email.value,
        address.value,
        admin.checked ? "X" : "-",
        
      ];
      let currentIndex = 0;
      let modify = false;
      for (let i = 0; i < table.rows.length; i++) {
        if (tableInfo[0] === table.rows[i].cells[0].innerText) {
          currentIndex = i;
          modify = true;
        }
      }
      if (modify) {
        var row = table.rows[currentIndex];
        for (let x = 0; x < row.cells.length; x++) {
          row.cells[x].innerText = tableInfo[x];
        }
        if (userimage.files[0] != null) {
          row.cells[row.cells.length - 1].innerText = "";
          var img = document.createElement("img");
          img.src = URL.createObjectURL(userimage.files[0]);
          img.height = 64;
          img.width = 64;
          img.style.display = "block";
          img.onload = () => {
            URL.revokeObjectURL(img.src);
          };
          row.cells[row.cells.length - 1].appendChild(img);
        }
      } 
      else {
        var newRow = table.insertRow();
        tableInfo.forEach((element) => {
          let newCell = newRow.insertCell();
          newCell.appendChild(document.createTextNode(element));
        });
        var imgCell = newRow.insertCell();
        var img = document.createElement("img");
        if (userimage.files[0] != null) {
          img.src = URL.createObjectURL(userimage.files[0]);
          img.height = 64;
          img.width = 64;
          img.onload = () => {
            URL.revokeObjectURL(img.src);
          };
        }
        imgCell.appendChild(img)
      }
      e.preventDefault();
    });
    emptyTable.addEventListener("click", function (e) {
      var tableHeaderRowCount = 1;
      var rowCount = table.rows.length;
      for (var i = tableHeaderRowCount; i < rowCount; i++) {
        table.deleteRow(tableHeaderRowCount);
      }
      e.preventDefault();
    });
  }