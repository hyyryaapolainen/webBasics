
var samples = [
    { id: 0, category: "Bass", src: "audio/bass.mp3", name: "Bass", duration: 7.49},
    { id: 1, category: "Drum", src: "audio/drum.mp3", name: "Drum", duration: 15},
    { id: 2, category: "Piano", src: "audio/piano.mp3", name: "Piano" },
    { id: 3, category: "Silence", src: "audio/silence.mp3", name: "Silence" },
    { id: 4, category: "Beat", src: "audio/strange-beat.mp3", name: "Strange Beat" },
    { id: 5, category: "Violin", src: "audio/violin.mp3", name: "Violin" },
  ];

var categories = [
    { id: 0, name: "Bass" },
    { id: 1, name: "Drum" },
    { id: 2, name: "Piano" },
    { id: 3, name: "Silence"},
    { id: 4, name: "Beat"},
    { id: 5, name: "Violin"}
]

function addCategoryButton(category)
{
    var categoryContainer = document.getElementById("category-selection")
    var button = document.createElement("button");
    button.className = "category-button";
    button.textContent = category.name;
  
    button.addEventListener("click", function() {
      setCurrentCategory(category.name);
    });
    categoryContainer.appendChild(button);
}

//BAD CODE PART
var draggedSample;
function addDraggableSampleButton(sample)
{   
    var div = document.createElement("div");
    div.className = "add-button";
    div.setAttribute("draggable", "true");
    div.textContent = sample.name;
    div.addEventListener("dragstart", function(event) {
        draggedSample = sample;
        /* cannot get this to work
        event.dataTransfer.setData("application/json", JSON.stringify(sample));
        console.log(event.dataTransfer.getData("application/json"))
        */
    });

    return div

}
async function getClipDuration(src) {
    const audioContext = new AudioContext(); 
    fetch(src) 
    .then(response => response.arrayBuffer()) 
    .then(buffer => audioContext.decodeAudioData(buffer)) 
    .then(audioBuffer => { 
      // Get the duration of the audio file 
      const duration = audioBuffer.duration; 
      console.log(`The audio file duration is ${duration} seconds`); 
    }); 
}

const uploadButton = document.getElementById("upload")
uploadButton.addEventListener("click", () => {
    const file = document.getElementById("input-sample").files[0]
    let audioSrc = ""
    if(!file) return
    
    audioSrc = URL.createObjectURL(file)
    let sample = {src: audioSrc, name: "New Sample"}
    samples.push(sample)
    id = samples.length - 1
    getClipDuration(audioSrc)
    /*
    let newButton = document.createElement("button")
    newButton.setAttribute("data-id", id)
    newButton.addEventListener("click", () => addSample(newButton))
    newButton.innerText = sample.name
    
    addButtons.appendChild(newButton)
    */


})


function generateSampleMenu(samples)
{
    var container = document.getElementById("sample-menu")
    samples.forEach((sample) => {
        let newButton = addDraggableSampleButton(sample)
        container.appendChild(newButton)

    })

}

function setCurrentCategory(categoryName) {

    var container = document.getElementById("sample-menu")
    container.innerHTML ="";

    var selectedCategory = categories.find(function(category){
        return categoryName === category.name;
    });
  
    if (selectedCategory) {
      var samples = findSamplesByCategory(selectedCategory.name)
      generateSampleMenu(samples)
    }
  }

function findSamplesByCategory(category)
{
    var filteredSamples = samples.filter(function(sample) {
        return sample.category.toLowerCase() === category.toLowerCase();
      });
    
      return filteredSamples;

}

async function setUpDocument()
{
    console.log(samples[0].src)
    await getClipDuration(samples[0].src)
    categories.forEach((category) => {
        addCategoryButton(category)
    })
    setCurrentCategory("Bass")

    const addTrack = document.getElementById("add-track");
    const removeTrack  = document.getElementById("remove-track");
    addTrack.addEventListener("click", function(){
        createNewTrack();
    })
    removeTrack.addEventListener("click", function(){
        removeSelectedTrack();
    })

}
function createSampleContainer(sample) {
    const sampleContainer = document.createElement('div');
    sampleContainer.classList.add('sample-container');
  
    const sampleArea = document.createElement('div');
    sampleArea.id = 'sample-area';
  
    const sampleText = document.createElement('p');
    sampleText.textContent = sample.name;
    sampleContainer.style.width = (sample.duration * 10)+"px"

    
  
    sampleArea.appendChild(sampleText);
    sampleContainer.appendChild(sampleArea);
  
    return sampleContainer;

}
function createNewDndArea()
{
    const dragDropArea = document.createElement('div');
    dragDropArea.classList.add('drag-drop-container');

    dragDropArea.addEventListener('dragenter', function (event) {
        event.preventDefault();
        dragDropArea.classList.add('drag-over');
        });
    
        dragDropArea.addEventListener('dragover', function (event) {
        event.preventDefault();
        });
    
        dragDropArea.addEventListener('dragleave', function (event) {
        event.preventDefault();
        dragDropArea.classList.remove('drag-over');
        });
    
        dragDropArea.addEventListener('drop', function (event) {
            event.preventDefault();
            dragDropArea.classList.remove('drag-over');
            const files = event.dataTransfer.files;
            var droppedData = event.dataTransfer.getData("text/plain");
            var sample = draggedSample;
            var mouseX = event.clientX;
            draggedSample = null;

            var container = document.getElementById(event.target.parentElement.id);
            var sampleArea = createSampleContainer(sample);
            var dndArea = createNewDndArea();
            container.appendChild(sampleArea)
            container.appendChild(dndArea);
            event.target.remove()
        });

    return dragDropArea;
}
function createNewTrack()
{
    trackContainer = document.getElementById("tracks")
    
    const singleTrack = document.createElement('div');
    singleTrack.classList.add('single-track');
    singleTrack.setAttribute('id', "Track"+trackContainer.children.length)
    
    const trackSamples = document.createElement('div');
    trackSamples.classList.add('track-samples');
    trackSamples.setAttribute('id', "track-samples"+trackContainer.children.length)
  
    const dragDropArea = createNewDndArea()

    trackSamples.appendChild(dragDropArea)
    singleTrack.appendChild(trackSamples);
    trackContainer.appendChild(singleTrack);

    addNewRadioButton()
}
function removeSelectedTrack()
{
    const trackRadios = document.getElementsByName("track");
    const selectedRadio = Array.from(trackRadios).find(radio => radio.checked);
  
    if (selectedRadio) {
        console.log(selectedRadio.value)
      const trackIndex = selectedRadio.value;
      const trackToRemove = document.getElementById("Track" + trackIndex);
  
      if (trackToRemove) {
        trackToRemove.parentNode.removeChild(trackToRemove);
        var labelToRemove = document.getElementById("track-label"+trackIndex)
        console.log(labelToRemove)
        labelToRemove.remove()
      }
      
      selectedRadio.parentNode.removeChild(selectedRadio);
    }
}

function addNewRadioButton()
{
    const radioContainer = document.getElementById("track-selections");
    const trackContainer = document.getElementById("tracks")
    const trackRadio = document.createElement("input");
    trackRadio.setAttribute("type", "radio");
    trackRadio.setAttribute("id", "track"+trackContainer.children.length);
    trackRadio.setAttribute("name", "track");
    trackRadio.setAttribute("value", trackContainer.children.length-1);
    trackRadio.checked = false;
    const trackLabel = document.createElement("label");
    trackLabel.setAttribute("for", "track"+trackContainer.children.length);
    trackLabel.setAttribute("id", "track-label"+(trackContainer.children.length-1).toString());
    trackLabel.innerText = "Track "+trackContainer.children.length;

    radioContainer.appendChild(trackRadio);
    radioContainer.appendChild(trackLabel);

}



if (document.readyState !== "loading") {
    console.log("Document is ready!");
    setUpDocument();
  } else {
    document.addEventListener("DOMContentLoaded", function () {
      console.log("Document is ready after waiting!");
      setUpDocument();
    });
  }